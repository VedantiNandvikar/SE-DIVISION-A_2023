from tkinter import *
window = Tk()
window.title("Grow Green")
window.config(background= 'light yellow')
window.geometry("1000x600")

orLabel=Label(text="Payment",font=('Nova Oval',20,'bold'),bg='light yellow')
orLabel.place(x=450,y=30)








window.mainloop()
